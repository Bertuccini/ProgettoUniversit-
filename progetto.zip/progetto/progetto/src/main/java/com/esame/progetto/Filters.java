package com.esame.progetto;

import java.util.ArrayList;


public class Filters {
	
	 //Metodo che filtra il contenuto della collection attraverso L'attributo "Attiva"
	 public static void LogFilter1 (ArrayList<StockRecords> database, double n){
		 int count=0;
		 ArrayList<StockRecords> recwithfilter = new ArrayList<StockRecords>();
		 for (int i=0; i<n; i++) {
			 if (database.get(i).getAttiva()==1) {recwithfilter.add(database.get(i)); count++;};
		 }
		 GetData.getData(recwithfilter,count);
	}
	 
	 //Metodo che filtra il contenuto della collection attraverso L'attributo "Zona"
     public static void LogFilter2 (ArrayList<StockRecords> database, double n){
		 
    	 int count=0;
    	
		 ArrayList<StockRecords> recwithfilterp = new ArrayList<StockRecords>();
		 for (int i=0; i<n; i++) {
			 if (database.get(i).getZona()%2==0) { recwithfilterp.add(database.get(i)); count++;}
		 }
		  
		 GetData.getData(recwithfilterp,count);	 
	 }
     
     //Metodo che filtra il contenuto della collection attraverso i valori di "Latitudine"
	 public static void CondFilter1 (ArrayList<StockRecords> database, double n){
		 
		 int count=0;
		 ArrayList<StockRecords> recwithfilter = new ArrayList<StockRecords>();
		 double m= GetStats.getLatStats(database, n);
		 for (int i=0; i<n; i++) {
			if (database.get(i).getLat() >= m) {recwithfilter.add(database.get(i));count++;};
		 }
		 GetData.getData(recwithfilter,count);
	}
	 
	 //Metodo che filtra il contenuto della collection attraverso i valori di "Longitudine"
     public static void CondFilter2 (ArrayList<StockRecords> database, double n){
		 
    	 int count=0;
		 ArrayList<StockRecords> recwithfilter = new ArrayList<StockRecords>();
		 double m= GetStats.getLonStats(database, n);
		 for (int i=0; i<n; i++) {
			 if (database.get(i).getLon()<m) {recwithfilter.add(database.get(i)); count++;};
		 }
		 GetData.getData(recwithfilter,count);
	}
}
