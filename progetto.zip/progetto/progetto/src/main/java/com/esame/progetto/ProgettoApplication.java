package com.esame.progetto;

import java.nio.file.FileAlreadyExistsException;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgettoApplication {

	//Metodo principale che effettua il download,il parse e permette all'utente, attraverso un menù, di ricevere i dati richiesti
	public static void main(String[] args) throws FileAlreadyExistsException {
		
		SpringApplication.run(ProgettoApplication.class, args);
		DownAndDec.Decode();
		StockData stockdata= new StockData();
		stockdata.LoadDatafromFile( DownAndDec.getFilename());
		
		System.out.println("Sono stati registrati " + stockdata.getNumberOfrecords() + " records");
		
		Scanner line= new Scanner(System.in);
		int val;
		int l,m;
		do {
				System.out.println("MENU'");	
				System.out.println("- Press 1 to GET/metadata");	
				System.out.println("- Press 2 to GET/data");	
				System.out.println("- Press 3 to GET/data statistics");	
				System.out.println("- Press 4 to GET/data with filters");
				System.out.println("- Press 5 to Exit");
				System.out.print("Inserisci: ");
			
			do {	
				val=line.nextInt();
				if (val!=1 && val!=2 && val!=3 && val!=4 && val!=5) System.out.println("Inserimento Errato");
		
			}while(val!=1 && val!=2 && val!=3 && val!=4 && val!=5);
		  
			
			switch (val) {
			case 1: GetData.getMetaData(stockdata.getRecords(),  DownAndDec.getFilename()); break;
			case 2: GetData.getData(stockdata.getRecords(), stockdata.getNumberOfrecords()); break;
			case 3: System.out.println("Seleziona il contenuto filtrato: ");
			          System.out.print("Inserisci 1 per Indirizzo , 2 per Attiva, 3 per Zona, 4 per Latitudine o 5 per Longitudine: ");
			          
			          m=line.nextInt();
				      
			          switch (m) {
			          case 1 : GetWords.getWords(stockdata.getRecords(), stockdata.getNumberOfrecords());break;
			          case 2 : GetStats.getNumberofActiveAreas(stockdata.getRecords(), stockdata.getNumberOfrecords());break;
			          case 3 : GetStats.getNumberofAddressinaZone(stockdata.getRecords(), stockdata.getNumberOfrecords());break;
			          case 4 : GetStats.getLatStats(stockdata.getRecords(), stockdata.getNumberOfrecords());break;
			          case 5 : GetStats.getLonStats(stockdata.getRecords(), stockdata.getNumberOfrecords());break;
			          default: System.out.println ("Inserimento Errato");break;
			          }
	                  
			        break;
            case 4:  System.out.println("Di quale attributo vuoi sapere le statistiche?");
	                 System.out.println("Inserisci 1 per filtrare i record con latitudine maggiore o uguale alla media");
	                 System.out.println("Inserisci 2 per filtrare i record con longitudine minore alla media");
	                 System.out.println("Inserisci 3 per filtrare i record delle zone attive");
	                 System.out.println("Inserisci 4 per filtrare i record delle zone pari");
	                 System.out.print("Inserisci: ");
	                 l=line.nextInt();
		      
	                 switch (l) {
	                case 1 : Filters.CondFilter1(stockdata.getRecords(), stockdata.getNumberOfrecords());break;
	                case 2 : Filters.CondFilter2(stockdata.getRecords(), stockdata.getNumberOfrecords());break;
	                case 3 : Filters.LogFilter1(stockdata.getRecords(), stockdata.getNumberOfrecords());break;
	                case 4 : Filters.LogFilter2(stockdata.getRecords(), stockdata.getNumberOfrecords());break;
	                default: System.out.println ("Inserimento Errato");break;
	                }
            
	                break;
            case 5: System.exit(0);
            line.close();
	    }
    }while(0==0);
  }
}

