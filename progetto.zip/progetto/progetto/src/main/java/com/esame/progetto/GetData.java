package com.esame.progetto;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

import org.json.simple.JSONObject;

public class GetData {
	
	//Metodo che restituisce tutti i dati presenti nella collection in formato Json
	public static void getData (ArrayList<StockRecords> database, int n) {
		
		JSONObject obj= new JSONObject();
		for (int i=0; i<n; i++)
		{			
			obj.put("Ind", database.get(i).getIndirizzo() );
			obj.put("Att", database.get(i).getAttiva());
			obj.put("ZonaDec", database.get(i).getZona());
			obj.put("Long", database.get(i).getLon());
			obj.put("Lat", database.get(i).getLat());
			obj.put("Loc", database.get(i).getLoc());
			
			System.out.println(obj);
		}
	}
	
	//Metodo che restituisce i metadati in formato Json
	public static void getMetaData (ArrayList<StockRecords> database, String filename) {
		
		try {		
		  Scanner file = new Scanner( new FileReader(filename));
		  String line="";
		  if (file.hasNext()) {
		  line=file.nextLine();
		  String[] attributi= line.split(";");
		  int l = attributi.length;
		  int i=0;	
		  while(i<l) {
			  JSONObject obj1= new JSONObject();
			  if (attributi[i].equals( "Indirizzo")) obj1.put("alias", "Ind");
			  else if (attributi[i].equals( "Attiva")) obj1.put("alias", "Att");
			  else if (attributi[i].equals( "ZonaDec")) obj1.put("alias", "ZonaDec");
			  else if (attributi[i].equals( "Longitudine")) obj1.put("alias", "Lon");
			  else if (attributi[i].equals( "Latitudine")) obj1.put("alias", "Lat");
			  else if (attributi[i].equals( "Location")) obj1.put("alias", "Loc");
			  obj1.put("sourceField", attributi[i]);
			  if (attributi[i].equals( "Indirizzo")) obj1.put("type", "string");
			  else if (attributi[i].equals( "Attiva") || attributi[i].equals("ZonaDec")) obj1.put("type", "integer");
			  else obj1.put("type", "double");
			  System.out.println(obj1);
			  i++;
		  }
		  }
		  file.close();
		  } catch (FileNotFoundException e) {
			  e.printStackTrace();
		  }
	}

}
